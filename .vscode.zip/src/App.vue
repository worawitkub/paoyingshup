<template>
  <div>
    <div id="app">
      <div class="player">
        <img :src="player1Image" alt="Player 1" />
      </div>
      <div class="player">
        <img :src="player2Image" alt="Player 2" />
      </div>
    </div>
    <p>Player 1: {{ player1Score }}</p>
    <p>Player 2: {{ player2Score }}</p>
    <button @click="playGame">เป่ายิ๊งงงงงงงงงฉุบ</button>
    <button @click="startNewGame">เริ่มใหม่</button>
  </div>
</template>

<script setup>
import { ref } from 'vue';

const images = [
  { url: 'https://inwfile.com/s-p/tdxunn.jpg', value: 1 },
  { url: 'https://png.pngtree.com/png-vector/20201030/ourlarge/pngtree-scissor-vector-illustration-png-image_2382884.jpg', value: 2 },
  { url: 'https://www.inkmanonline.com/images/content/original-1617779996418.jpg', value: 3 },
  { url: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrs54LepW0s6fY7dLZ6dYzKqBwVSPrgdu8cw&usqp=CAU', value: 4 },
];

const player1Image = ref('');
const player2Image = ref('');
const player1Score = ref(0);
const player2Score = ref(0);

function getRandomNumber() {
  return Math.floor(Math.random() * images.length);
}

function playGame() {
  const player1Index = getRandomNumber();
  const player2Index = getRandomNumber();

  player1Image.value = images[player1Index].url;
  player2Image.value = images[player2Index].url;

  if (images[player1Index].value > images[player2Index].value) {
    player1Score.value += 1;
  } else if (images[player1Index].value < images[player2Index].value) {
    player2Score.value += 1;
  }
}

function startNewGame() {
  player1Score.value = 0;
  player2Score.value = 0;
  player1Image.value = '';
  player2Image.value = '';
}
</script>

<style scoped>
#app {
  display: flex;
  justify-content: center;
  align-items: center;
}

.player {
  text-align: center;
  margin: 0 20px;
}
.player img {
  width: 200px; /* กำหนดความกว้าง */
  height: 200px; /* กำหนดความสูง */
}
template{
  background-color: rgb(228, 183, 125);
}
</style>
